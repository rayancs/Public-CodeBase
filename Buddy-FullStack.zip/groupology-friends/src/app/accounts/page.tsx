import UserDasboard from "@/components/user-dashboard/User-Dasboard";

export default function accountsPage(){
    return(
         <UserDasboard/>   
)
}