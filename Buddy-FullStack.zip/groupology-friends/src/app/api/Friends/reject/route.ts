import { acceptFriendRequest, addFriend, getFriendsData, remove_friend } from "@/services/Accounts";
import log from "@/services/messager_for_api";
import { NextApiRequest, NextApiResponse } from "next";
import { NextResponse } from "next/server"
export async function POST(req:Request){
    const body = await req.json();
    const {user} = body;
    if (!user.email){
    return NextResponse.json({message:"Bad Request"},{status:404})
    }
    console.log(user.email)
    const res = await remove_friend(user.email)
    if (!res){
        return NextResponse.json({message:log("We Faced Some Issues On our Side")},{status:404})
    }
    return NextResponse.json({message:log("Friend Deleted")},{status:200})

}