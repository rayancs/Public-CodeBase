import { addFriend, getFriendsData } from "@/services/Accounts"
import log from "@/services/messager_for_api";
import { NextApiRequest, NextApiResponse } from "next";
import { NextResponse } from "next/server";

export async function POST(req:Request) {
    
    const body = await req.json();
    const {friends} = body;
    try{
        const friendEmail = friends.email
        var res =await addFriend(friendEmail)
        if (res == 'not_logged_in'){
            return NextResponse.json(log("User Session Not Found"),{status:401})
        }
        if (res == 'req_already_sent'){
            return NextResponse.json(log("Request Already Sent to "+friendEmail),{status:200})
        }
        if (res == null){
            return NextResponse.json(log("Account Not Found "+friendEmail),{status:204})
        }
        return  NextResponse.json(log("Request Sent to "+friendEmail),{status:200})
    }catch(error){
        throw error
    }
}
export async function GET(){
    var res =await getFriendsData();
   if (res == null){
   return NextResponse.json({message:"form-validation-error"},{status:401})
   }
   return NextResponse.json({res},{status:201})
}