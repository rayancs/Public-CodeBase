import { create_groups, get_all_groups } from "@/services/Groups";
import log from "@/services/messager_for_api";
import { NextResponse } from "next/server"
import { group_model } from "@/models/groups_model";
export async function POST(req:Request){
    const body = await req.json();
    const {group} = body;
    console.log(group)
    const res = await create_groups(group)
    if (!res){
        return NextResponse.json({message:log("We Faced Some Issues On our Side")},{status:404})
    }
    if (res == 404){
        return NextResponse.json({message:log("User Session Not Found")},{status:404})
    }
    if(res == 204){
        return NextResponse.json({message:log("Problem While Making The Group , Please Contact Us")},{status:200})
    }
    return NextResponse.json({message:log("Friend Request Accepted")},{status:200})
}
export async function GET(){
    const res = await get_all_groups();
    if (!res){
        return NextResponse.json({message:log("We Faced Some Issues On our Side")},{status:404})
    }
    return NextResponse.json({res},{status:200})
}