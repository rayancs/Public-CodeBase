import { db } from '@/lib/db';
import { loginUser } from '@/services/Accounts';
import log from '@/services/messager_for_api';
import { NextResponse } from 'next/server';
export  async function GET(){
   var res =await loginUser()
   if (res == null){
   return NextResponse.json({message:log("Form Invalid")},{status:401})
   }
   return NextResponse.json({res},{status:201})
}


