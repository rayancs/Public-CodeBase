import { FindPeopleComponent } from "@/components/findPeople/findPeople";

export default function findpeople(){
    return(
        <>
        <FindPeopleComponent/>
        </>
    )
}