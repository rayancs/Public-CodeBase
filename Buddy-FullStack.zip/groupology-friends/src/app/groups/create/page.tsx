'use client'
import EventSelectorPage, { CreateGroupComponent } from "@/components/groups-components/_EventSelectorPage"
export default function Page(){
    return(    
    <>
     <CreateGroupComponent/>
    </>
    )
}