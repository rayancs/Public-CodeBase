'use client'
import Groupscomponent from '@/components/groups-components/groups-component'
import React from 'react'

const page = () => {
  return (
    <>
    <Groupscomponent/>
    </>
  )
}

export default page