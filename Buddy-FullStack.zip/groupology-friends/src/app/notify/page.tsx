import { MainNotifications } from "@/components/notifications/MainNotifications";

export default function notify(){
    return(
    <>
    <MainNotifications/>
    </>       
    )
}