import {Homecomponent} from "@/components/home/_home-component";
import Image from "next/image";

export default function Home() {
  return (
   <>
   <Homecomponent/>
   </>
  );
}
