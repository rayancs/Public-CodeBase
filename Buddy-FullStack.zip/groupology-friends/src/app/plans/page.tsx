import { EventComponent } from "@/components/plans/plans";

export default function Page(){
    return(
        <>
        <EventComponent/>
        </>
    )
}