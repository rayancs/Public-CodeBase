'use client'
import React, { useEffect, useState } from 'react'
import { BsSearch, BsX } from 'react-icons/bs'
import Notifications from '../ui/notifications'
type user = {
  email:string
  firstname:string
  isAccepted:boolean
  picture:string
  
}
export const FindPeopleComponent = () => {
  const [requests , set_requests] = useState<user[]>([]);
  const [show_options , set_show_options] = useState<boolean[]>([])
  const [response_notification , set_response_notification] = useState<string>()
  const [email, setEmail] = useState<string>('');

  const GetFriendsData = async ()=>{
    try{
        const _res = await fetch('/api/friends',{
            method:"GET",
            headers:{
                "Content-Type":"application/json"
            }
        }).then((res)=>res.json()).then((data)=>{
            // data.res will reveal the data array from the result object
            // this is working 
            set_requests(data.res.friend)

        })            
    }catch (error){
        console.log(error)
    };
  }
  const handleSubmit =async (e: React.FormEvent<HTMLFormElement>)=>{
    e.preventDefault()
    try {
      const response = await fetch('/api/friends', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ friends: { email } }),
      });
      if (!response.ok) {
        throw new Error('Failed to submit form data');
      }
      // Handle successful response
      const responseData = await response.json()
      set_response_notification(responseData.res.str)
      //do the notifcation implementaion here

    } catch (error) {
      console.error('Error submitting form data:', error);
    }
  };
  const show_more_options=(index:number )=>{
    const updated_opt = [...show_options]
    updated_opt[index]= !show_options[index]
    set_show_options(updated_opt)
  }
  function remove_user_from_list( index:number){
    const updatedArray =[...requests]
    const filter = updatedArray.filter((_,_index)=>_index !== index)
    set_requests(filter)

  }
  async function reject_request(email:string){
    try{
      const res = await fetch('api/friends/reject',{
        method:'POST',
        headers:{
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user:{email}})
      });
      if(!res.ok){
        throw new Error('Failed to submit form data');
      }
      console.log('Form data submitted successfully'+res);
    }
    catch(ex){
      console.log(ex)
    }
  }
  useEffect(()=>{
    GetFriendsData()
  },[])
  return (
    <>
        <Notifications str={response_notification}/>)
        
        <div className='w-screen h-auto'>
            <div className='w-[98%] h-32 bg-zinc-900 flex mx-auto rounded-b-3xl max-w-[640px] flex-col'>
                  <form className=' flex flex-row justify-evenly items-center h-full' onSubmit={handleSubmit}>
                    <div className='h-10 flex flex-row'>
                        <input 
                        type="text" 
                        id="base-input"
                        value={email}
                        onChange={(e) => {setEmail (e.target.value) ; console.log(email)}}
                        className="bg-zinc-800 hover:bg-zinc-500 transition-all ease-in-out duration-200 outline-none text-zinc-200  w-80 h-10 text-sm rounded-full rounded-r-none focus:ring-transparent focus:border-transparent block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"/>
                        <button className=' w-10 rounded-r-full bg-zinc-800 h-10 flex justify-evenly items-center  '><BsSearch className='text-zinc-200 hover:text-zinc-500'/></button>
                    </div>

                  </form>
            </div>
            <section>
              <div className=' mt-7 '>
                <p className='text-3xl mx-auto w-3/3 pl-2 sm:w-3/4 font-bold text-zinc-300'>
                Your People Are Here
                </p>
              </div>
            </section>
            <section>
            <div className='w-full sm:grid sm:grid-cols-2 flex flex-col sm:grid-flow-col '>
                      {requests?.filter(x=>x.isAccepted).map((x , identifier) =>(
                        <div key={identifier} onClick={()=>show_more_options(identifier)} className={`relative  overflow-hidden w-[95%] sm:w-[100] flex flex-row h-20 border-t border bg-zinc-800 rounded-xl border-zinc-800 mx-auto mt-5`}>
                          <div className='w-2/6'>
                            <span>
                              <img src={x.picture} className=' ml-2 mt-2 shadow-sm h-auto  w-9 rounded-full '/>
                            </span>
                          </div>
                          <div>
                            <p className=' text-zinc-400 pt-2 h-9 w-full overflow-hidden'>
                              {x.firstname}
                            </p>
                            <p className='text-zinc-600 text-xs'>
                            {x.email}
                            </p>
                          </div>
                        
                          <div id='overlay' className={` ${show_options[identifier] ? ' bottom-0': ' -bottom-32'}  left-0 w-full h-full absolute glass  transition-all ease-in-out duration-200 `}>
                            <div className=' flex flex-row justify-evenly items-center h-full'>
                              <button className=' w-10 h-10 bg-red-600 bg-opacity-30 border-red-500 border rounded-full '>
                                <BsX onClick={()=>{
                                  remove_user_from_list(identifier)
                                  reject_request(x.email)
                                  }} className='h-9 w-9 text-red-200'></BsX>
                              </button>
                            </div>

                          </div>
                      </div>
                      ))
                      }
                </div>
            </section>
         
          </div>
        <style jsx>
              {
                  `
                  .glass{
                    backdrop-filter: blur(5px);
                    -webkit-backdrop-filter: blur(5px);
                    }
            .custom-width{
                max-width:1024px;
            }
            @media screen and (max-width: 768px) {
                .custom-width {
                  width: 95%; /* Set width to 95% for phone screens 
                }
            }
            
            `
              }
              
          </style>
    </>
  )
}
