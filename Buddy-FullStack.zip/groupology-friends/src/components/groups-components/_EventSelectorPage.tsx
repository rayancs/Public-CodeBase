'use client'
import Person from '@/assets/person.png'
import React, { useEffect, useState } from 'react'
import { BiSkipNext } from 'react-icons/bi';
import {  BsCaretDownFill, BsHandThumbsUpFill, BsPatchCheck, BsPatchCheckFill, BsPlayFill, BsPlus, BsX } from 'react-icons/bs';
import { GrFormNext, GrFormPrevious, GrGroup } from 'react-icons/gr';
import { useRouter } from 'next/router';
import { redirect } from 'next/navigation';
import { navigate_to_home } from '@/services/actions';
type user = {
  email:string
  firstname:string
  isAccepted:boolean
  picture:string
  
}
export const CreateGroupComponent = () => {
  // all of the stages for creating a task
  const [stage_1 , set_stage_1] = useState<boolean>(false)
  const [stage_2 , set_stage_2] = useState<boolean>(false)
  const [stage_3 , set_stage_3] = useState<boolean>(false)
  const [stage_4 , set_stage_4] = useState<boolean>(false)
  const [stage_5, set_stage_5]  = useState<boolean>(false);
  // this is to scroll through tgge array ( local_people_array) stage-4
  const [scroll, set_scroll] = useState<number>(0);
  const [isOpen,setIsOpen] = useState<boolean>(false);
  const [requests , set_requests] = useState<user[]>([]);
  const [show_options , set_show_options] = useState<boolean[]>([])
  // this will contain info about the people array array that is supposed to be sent to the api 
  const [local_people_array , set_local_people_array] = useState<Array<string>>([]);
  // this is for the description 
  const [group_name , set_group_name] = useState<string>();
  const [task_name , set_task_name] = useState<string>();
  // this is for task description 
  const[task_description , set_task_description] = useState<string>();
  // this is for the for_email section in the post request 
  const[for_email , set_for_email] = useState<string>();
  // this is for the response notificationn state 
  const [response_notification , set_response_notification] = useState<string>()
  const [email, setEmail] = useState<string>('');
  const open =()=>{
    setIsOpen(!isOpen)
    console.log(isOpen)
  }
  const GetFriendsData = async ()=>{
    try{
        const _res = await fetch('/api/friends',{
            method:"GET",
            headers:{
                "Content-Type":"application/json"
            }
        }).then((res)=>res.json()).then((data)=>{
            // this is working 
            set_requests(data.res.friend)

        })            
    }catch (error){
        console.log(error)
    };
  }
 
  const show_more_options=(index:number )=>{
    const updated_opt = [...show_options]
    updated_opt[index]= !show_options[index]
    set_show_options(updated_opt)
  }
  function remove_user_from_list( index:number){
    const updatedArray =[...requests]
    const filter = updatedArray.filter((_,_index)=>_index !== index)
    set_requests(filter)

  }
  function add_people (index:number){
    const updatedArray = [...local_people_array]; // Create a copy of the existing array
    const userToAdd = requests[index]; // Get the user object at the specified index
    updatedArray.push(userToAdd.email); // Add the email of the user to the updated array
    set_local_people_array(updatedArray); // Update the state with the updated array
  }
  // post to the api 
  useEffect(()=>{
    if (stage_5 == true){
      console.log('stage - 5 - ture ')
      const post = async()=>{
        try{
          const res = await fetch('/api/group',{
            method:'POST',
            headers:{
              'Content-Type':'application/json',
            },
            body:JSON.stringify({
              group:{
                name:group_name,
                admin_email:'',
                people:local_people_array,
                tasks:[
                  {
                    for_email:for_email,
                    title:task_name,
                    Description:task_description,
                    
                  }
                ]
              }
            })
          });
          
          if (res.ok){
            navigate_to_home()
          }
        }catch(ex){
          console.log(ex);
        }
      }
      post();
    };
    
  },[stage_5])

  useEffect(()=>{
    GetFriendsData()
  },[])
  useEffect(()=>{
    console.log(local_people_array)
  },[local_people_array ])
  return (
    
    <>
    <div className='relative w-screen overflow-hidden '>
        <button
        onClick={()=>{
          setIsOpen(true)
          }
        }
         className={`absolute ${isOpen ? ' -bottom-20 -z-10  opacity-0' : 'bottom-20'} duration-200 transition-all ease-linear  hover:animate-nones left-1/2 h-12 w-32  -translate-x-1/2 z-50 inline-flex items-center justify-center  p-4 px-5 py-3 overflow-hidden font-medium text-indigo-600 rounded-lg shadow-2xl group`}>
          <span className="absolute top-0 left-0 w-40 h-40 -mt-10 -ml-3 transition-all duration-700 bg-red-500 rounded-full blur-md ease"></span>
          <span className="absolute inset-0 w-full h-full transition duration-700 group-hover:rotate-180 ease">
          <span className="absolute bottom-0 left-0 w-24 h-24 -ml-10 bg-purple-500 rounded-full blur-md"></span>
          <span className="absolute bottom-0 right-0 w-24 h-24 -mr-10 bg-pink-500 rounded-full blur-md"></span>
          </span>
          <span className="relative  text-zinc-800 font-bold text-2xl">LES'GOO</span>
        </button>
        <div className=' w-[95%] max-w-[1280px] h-auto mx-auto mt-5 '>
            <section>
              <div className={`absolute h-4/6 sm:4/6 md:5/6  w-full rounded-t-3xl  transition-all ease-in-out duration-300 bg-zinc-300 ${ isOpen ? 'left-0 bottom-0' : ' -bottom-[100vh]'}`}>
                          <div className=' w-[95%]'>
                            <div className=' h-2/6'>
                              <p className=' text-6xl sm:text-7xl  text-start ml-8 mt-8 '>
                                  Group
                              </p>
                              <p className='text-7xl font-bold text-start ml-8'>
                              Name
                              </p>
                            </div>
                            <section id='form'>
                              <div className=' w-[80%] max-w-[740px] h-12 bg-zinc-800 rounded-sm mx-auto mt-5 mb-4'>
                                <input
                                value={group_name}
                                onChange={(e)=>{
                                  set_group_name(e.target.value)
                                }}
                                className=' w-full h-12 bg-zinc-200 border-t-2 rounded-md border-l-2 border border-zinc-800 outline-none text-center -translate-x-1 -translate-y-1' placeholder='Give it a Name'>
                                </input>
                              </div>
                            </section>
                            <div className='w-full flex justify-evenly mt-4 items-center'>
                              <button onClick={()=>{
                               setIsOpen(true)
                              set_stage_2(true)}
                               } className=' w-44  mx-auto h-12 bg-zinc-900 text-zinc-200 flex flex-row items-center justify-evenly rounded-sm'>
                                <BsPlayFill className='text-3xl'></BsPlayFill>Whats Next
                              </button>
                            </div> 
                          </div>
                </div>
              </section>
          <section>
            <div className=' mt-7 '>
              <p className='text-3xl mx-auto w-3/3 pl-2 sm:w-3/4 font-bold text-zinc-300'>
              Lets Add Some Friends
              </p>
            </div>
          </section>
              <section>
              <div className='w-full sm:grid sm:grid-cols-2 flex flex-col sm:grid-flow-col '>
                        {requests?.filter(x=>x.isAccepted).map((x , identifier) =>(
                          <div key={identifier} onClick={()=>show_more_options(identifier)} className={`relative  overflow-hidden w-[95%] sm:w-[100] flex flex-row h-20 border-t border bg-zinc-800 rounded-xl border-zinc-800 mx-auto mt-5`}>
                            <div className='w-2/6'>
                              <span>
                                <img src={x.picture} className=' ml-2 mt-2 shadow-sm h-auto  w-9 rounded-full '/>
                              </span>
                            </div>
                            <div>
                              <p className=' text-zinc-400 pt-2 h-9 w-full overflow-hidden'>
                                {x.firstname}
                              </p>
                              <p className='text-zinc-600 text-xs'>
                              {x.email}
                              </p>
                            </div>
                          
                            <div id='overlay' className={` ${show_options[identifier] ? ' bottom-0': ' -bottom-32'}  left-0 w-full h-full absolute bg-zinc-300  text-zinc-800  transition-all ease-in-out duration-200 `}>
                              <div className=' flex flex-row justify-evenly items-center h-full'>
                                <p className='text-xs font-thin'> Tap To Add</p>
                                <button className=' w-10 h-10  bg-opacity-30  rounded-full '>
                                  <GrGroup onClick={()=>{
                                    add_people(identifier)
                                    remove_user_from_list(identifier)
                                    }} className='h-8 w-8 text-zinc-800 scale-110 transition-all ease-in-out duration-200 hover:text-green-900'/>
                                </button>
                              </div>

                            </div>
                        </div>
                        ))
                        }
                  </div>
              </section>
              
            
            </div>
              <section>
              <div className={`absolute h-4/6 sm:4/6 md:5/6  w-full rounded-t-3xl  transition-all ease-in-out duration-300 bg-zinc-300 ${ stage_2 ? 'left-0 bottom-0' : ' -bottom-[100vh]'}`}>
                          <div className=' w-[95%]'>
                            <div className=' h-2/6'>
                              <p className=' text-6xl sm:text-7xl  text-start ml-8 mt-8 '>
                                  Time For A 
                              </p>
                              <p className='text-7xl font-bold text-start ml-8'>
                              Task
                              </p>
                            </div>
                            <section id='form'>
                              <div className=' w-[80%] max-w-[740px] h-12 bg-zinc-800 rounded-sm mx-auto mt-5 mb-4'>
                                <input
                                value={task_name}
                                onChange={(e)=>{
                                  set_task_name(e.target.value)
                                }}
                                className=' w-full h-12 bg-zinc-200 border-t-2 rounded-md border-l-2 border border-zinc-800 outline-none text-center -translate-x-1 -translate-y-1' placeholder='Give it a Name'>
                                </input>
                              </div>
                            </section>
                            <div className='w-full flex justify-evenly mt-4 items-center'>
                              <button onClick={()=>{
                               set_stage_2(false)
                              set_stage_3(true)}
                               } className=' w-44  mx-auto h-12 bg-zinc-900 text-zinc-200 flex flex-row items-center justify-evenly rounded-sm'>
                                <BsPlayFill className='text-3xl'></BsPlayFill>Whats Next
                              </button>
                            </div> 
                          </div>
                </div>
              </section>
              <section>
              <div className={`absolute h-5/6  w-full rounded-t-3xl  transition-all ease-in-out duration-300 bg-zinc-300 ${ stage_3 ? 'left-0 bottom-0' : ' -bottom-[100vh]'}`}>
                          <div className=' w-[95%]'>
                            <div className=' h-2/6 sm:mb-10'>
                              <p className=' text-6xl sm:text-7xl  text-start ml-8 mt-8 '>
                                Lets Give It A
                              </p>
                              <p className='text-6xl font-bold text-start ml-8'>
                              Description
                              </p>
                            </div>
                            <section id='form'>
                              <div className=' w-[80%] max-w-[740px] h-32 bg-zinc-800 rounded-sm mx-auto mt-5 mb-4'>
                                <textarea
                                value={task_description}
                                onChange={(e)=>set_task_description(e.target.value)} 
                                className=' resize-none w-full h-32 bg-zinc-200 border-t-2 rounded-md border-l-2 border border-zinc-800 outline-none text-center -translate-x-1 -translate-y-1' placeholder='Give it a Name'>
                                </textarea>
                              </div>
                            </section>
                            <div className='w-full flex justify-evenly mt-4 items-center'>
                              <button onClick={()=>{
                                set_stage_3(false)
                                set_stage_4(true)
                                }
                               } className=' w-44  mx-auto h-12 bg-zinc-900 text-zinc-200 flex flex-row items-center justify-evenly rounded-sm'>
                                <BsPlayFill className='text-3xl'></BsPlayFill>Whats Next
                              </button>
                            </div> 
                          </div>
                </div>
              </section>
              <section>
              <div className={`absolute h-4/6  w-full rounded-t-3xl  transition-all ease-in-out duration-300 bg-zinc-300 ${ stage_4 ? 'left-0 bottom-0' : ' -bottom-[100vh]'}`}>
                          <div className=' w-[95%]'>
                            <div className=' h-2/6 sm:mb-10'>
                              <p className=' text-6xl sm:text-7xl  text-start ml-8 mt-8 '>
                                Whos it
                              </p>
                              <p className='text-6xl font-bold text-start ml-8'>
                              FOR ?
                              </p>
                            </div>
                              
                              <section id='form'>
                              <div className='max-w-[400px] h-12 mt-4 w-80 bg-green-900 mx-auto'>
                                <p
                                onClick={
                                  ()=>{
                                    set_for_email(local_people_array[scroll])
                                    set_stage_4(false)
                                    set_stage_5(true)
                                  }
                                } 
                                className='text-xl font-semibold text-green-900 max-w-[400px] h-12  bg-green-400 -translate-x-1 flex flex-col overflow-hidden items-center justify-center text-center  translate-y-1 hover:translate-x-1 hover:-translate-y-1 transition-all ease-in-out duration-200 '>
                                  {local_people_array[scroll]}
                                </p>
                              </div>
                            </section>
                            <div className='w-full flex justify-around mt-10 items-center'>
                              <button onClick={()=>{
                                if (scroll < local_people_array.length - 1) {
                                  set_scroll(scroll + 1);
                                }
                                }
                               }
                               disabled={scroll === local_people_array.length - 1}
                               className=' w-12  mx-auto h-12 bg-zinc-900 text-zinc-200 flex flex-row items-center justify-evenly rounded-full'>
                                <GrFormPrevious className='text-3xl'></GrFormPrevious>

                              </button>
                              <button onClick={()=>{
                              
                                  if (scroll < local_people_array.length - 1) {
                                    set_scroll(scroll + 1);
                               }
                              }
                            } disabled={scroll === local_people_array.length - 1}
                               className=' w-12 rounded-full  mx-auto h-12 bg-zinc-900 text-zinc-200 flex flex-row items-center justify-evenly'>
                                <GrFormNext className='text-3xl'></GrFormNext>
                              </button>
                            </div> 
                          </div>
                </div>
              </section>
              <section>
              <div className={`absolute h-full  w-full   transition-all ease-in-out  duration-300 bg-zinc-300 ${ stage_5 ? 'left-0 bottom-0' : ' -bottom-[100vh]'}`}>
                          <div className=' w-[95%] mx-auto flex h-full items-center justify-evenly'>
                            <p className=' animate-pulse md:text-3xl'>
                              Almost Done !
                            </p>
                           </div>
                </div>
              </section>
            
          </div>
              
          <style jsx>
              {
                  `
                  .glass{
                    backdrop-filter: blur(5px);
                    -webkit-backdrop-filter: blur(5px);
                    }
            .custom-width{
                max-width:1024px;
            }
            @media screen and (max-width: 768px) {
                .custom-width {
                  width: 95%; /* Set width to 95% for phone screens 
                }
            }
            
            `
              }
              
          </style>
   
    </>
  )
}
export default CreateGroupComponent

