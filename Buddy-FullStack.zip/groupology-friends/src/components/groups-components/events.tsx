import React, { useEffect, useRef, useState } from 'react'
import MiniBadge from '@/components/ui/MiniBadge'
import Link from 'next/link';
interface data {
    // req section
    UUID :string
    GroupName: string;
    people:string[]
    num:number
  }
  
export const Events:React.FC<data> = ({
UUID,
GroupName,
people,
num
}) =>{
    // variable declaration 
const inputRef = useRef<HTMLInputElement>(null);
const [peopleShort , setPeopleShort] = useState<string[]>();
const badgeIconSize = 10;
// to get the taks name , lets say task is helens project , this is gonna give you H 
const getEvent = GroupName.charAt(0).trim();
function processArray(inputArray: string[]): string[] {
    // Extract 5 items from the input array
    const trimmedArray = inputArray.slice(0, 5);
    
    // Trim each item to a maximum length of 10 characters
    const processedArray = trimmedArray.map(item => item.substring(0, 10));
    var totalPeople = people.length - 5
    if (totalPeople >0){
    processedArray.push(totalPeople+' more')
    }
  
    return processedArray;
  }
  useEffect(()=>{setPeopleShort(processArray(people))},[])
  
  return (
    <>
    <Link href={`/${UUID}`}> 
    <div className={`w-full h-32 bg-zinc-950  text-zinc-200 sm:h-36 flex flex-row border-t border-zinc-900 mt-3 pt-1`}>
    <div className="w-2/6 flex items-center justify-around h-full">
        <div className={`h-24 sm:h-28 w-24 sm:w-28 rounded-full bg-zinc-700 text-zinc-200  flex flex-col items-center justify-evenly`}>
            <p className="font-bold text-4xl flex items-center">
                {getEvent}
            </p>
        </div>
    </div>
    <div className="w-4/6 h-full">
        <div className=' w-full flex justify-end'>
        <MiniBadge count={num} badgeColor={'bg-zinc-200 text-zinc-900'} padding={"mr-2"}>
                <svg xmlns="http://www.w3.org/2000/svg" width={badgeIconSize} height={badgeIconSize} 
                    className="bi bi-clipboard-check" viewBox="0 0 16 16">
                    <path fill-rule="evenodd"
                        d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0" />
                    <path
                        d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1z" />
                    <path
                        d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0z" />
                </svg>
            </MiniBadge>
        </div>
            <div className=" mt-1">
                <p className=' text-xl sm:text-3xl'>
                    {GroupName}
                </p>
            </div>
            <div id='array-mapper' className=' mt-2'>
                {peopleShort?.map((x,index)=>(
                    <span className='text-xs text bg-zinc-800 text-center pl-1 pr-1 text-zinc-400 rounded-full m-1' key={index}>
                        {x}
                    </span>
                ))}
            </div>
        </div>
    </div>

    </Link>
    </>
    )
}
 


export default Events