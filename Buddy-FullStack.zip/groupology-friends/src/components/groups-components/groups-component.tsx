import React, { useEffect, useState } from 'react'
import Topbar from './topbar'
import { EventComponent } from '../plans/plans'
import {  Events} from"./events";
type group={
  id:string,
  admin_email:string,
  name:string,
  people:string[],
  tasks:[{
    for_email:string,
    title:string,
    Description:string,
    end_date:string
  }]
}
const Groupscomponent = () => {
  // fetch method
  const [group_data , set_group_data] = useState<group[]>([]);
  const fetch_group_info = async()=>{
    try{
     await fetch('/api/group',{
        method:"GET",
        headers:{
            "Content-Type":"application/json"
        }
    }).then((res)=>res.json()).then((data)=>{
        // data.res will reveal the data array from the result object
        // this is working
        console.log(data.res)
        set_group_data(data.res);
    })     
    }catch(ex){
    }
  }
  useEffect(()=>{
    fetch_group_info()
  },[])
  return (
    <>
    <div className='w-[95%] mx-auto max-w-[1280px]'>
        <Topbar/>
        { /*on a pc / windows this should be on left and right ride left side indicating groups and then right side indicating tasks in the group*/}
        <section id='all groups'>

         {/* <div className=' flex w-full flex-row' id='contianer'>*/}
            {/* left side :: Group info*/}
            {/*
            <div className=' w-3/6 overflow-y-scroll'>
              <div className=' w-[98%] h-24 md:h-32 flex flex-row justify-between rounded-sm mx-auto mt-1'>
                <div id='image/text-section' className=' rounded-l-xl bg-zinc-200 w-1/6'>
                    <p className=' rotate-0 text-3xl'>
                      G
                    </p>
                </div>
                <div className='bg-zinc-800 rounded-r-sm w-5/6'>

                </div>
              </div>
            </div>
            <div className=' w-3/6  h-24 bg-blue-200'>

            </div>
          </div> */}
          {/* temp*/}
          {group_data.map((group, index) => (
            <Events
              key={index} // Adding a unique key is important when rendering lists in React
              GroupName={group.name}
              num={ group.people.length}
              UUID={group.id} 
               people={group.people}/>
          ))}
        </section>
    </div>
    </>
  )
}

export default Groupscomponent