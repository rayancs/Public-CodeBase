import Link from 'next/link'
import React from 'react'
import { GrAdd} from 'react-icons/gr'

const Topbar = () => {
  return (
    <>
     {/*<div className='border-custom h-40 sm:h-28 sm:mt-5'>
            <div className=' flex flex-row h-full justify-between' id='Page-Inforamtion'>
                <div className='w-2/6 h-full flex flex-col items-center justify-evenly'>
                    <p className={`text-zinc-200 text-3xl w-full font-bold`}>
                        {'My Groups'}
                    </p>
                    <p className={`text-zinc-200 text-xs font-thin w-full flex items-start pl-1  `}>
                        {'Creat or Manage Exsiting Groups'}
                    </p>
                </div>
                <div className='w-4/6 flex items-center justify-end'>
                    <div className='w-5/6 h-10 max-w-[200px] bg-zinc-300'>
                        <Link href={'/groups/create'} className='w-5/6 -translate-x-1 translate h-10 max-w-[200px] hover:bg-zinc-300 hover:text-zinc-900 active:bg-zinc-500 active:text-zinc-100 outline-none transition-all flex  justify-evenly items-center flex-row-reverse text-lg text-center rounded-sm  duration-300 ease-in-out  text-zinc-200 bg-zinc-700'
                            >
                        Create Group
                        <GrAdd/>
                        </Link>
                    </div>
                    
                </div>
            </div>
  </div>*/}
        <div className='h-44 mt-2 rounded-sm mb-1'>
            <div className='flex flex-row items-center justify-between'>
                <div>
                    <p  className='text-2xl mt-4 text-zinc-200' >
                        Your 
                    </p>
                    <p  className='text-5xl font-semibold text-zinc-200' >
                        Groups
                    </p>
                </div>
                   
                    <div className=' h-12 w-32 mt-4 bg-zinc-500 rounded-sm'>
                        <Link href={'groups/create'}  className=' flex flex-row items-center justify-evenly  text-xl bg-lime-400 h-12 w-32 rounded-sm animate duration-200 transition-all ease-in-out -translate-x-1 -translate-y-1 hover:translate-x-1 hover:translate-y-1 active:translate-x-1 active:translate-y-1 '>
                            Create
                            <GrAdd/>
                        </Link>
                    </div>
            </div>
        </div>
    </>
   
  )
}

export default Topbar