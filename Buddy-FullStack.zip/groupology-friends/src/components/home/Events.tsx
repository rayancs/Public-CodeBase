import Link from "next/link";
import React from "react";
import MiniBadge from "./MiniBadge";

interface data {
  // req section
  GroupName: string;
  Update: string;
  Issues: string;
  messages: string[];
  messageCount:string;
}

export const Events: React.FC<data> = ({
    GroupName,
    messages,
    messageCount,
    Update,
    Issues,
}) => {
  const badgeIconSize = 10;
  const GroupName_styleElement = GroupName.charAt(0).toUpperCase();
  return (
    <Link href={"/###"}>
      <div
        className={`w-auto h-32 bg-zinc-950 text-zinc-200 flex flex-row mt-3 rounded-lg`}
      >
        <div className="w-2/6 flex items-center justify-around h-full">
          <div
            className={`h-24 w-24 rounded-full bg-zinc-800 flex flex-col items-center justify-evenly`}
          >
            <p className="font-bold text-4xl text-zinc-200 flex items-center">
              {GroupName_styleElement}
            </p>
          </div>
        </div>
        <div className="w-4/6 h-full">
          <div className="h-1/6 w-full flex items-center flex-row justify-end">
            <MiniBadge count={messageCount} badgeColor={'bg-zinc-800 text-zinc-200'} padding={"mr-2"}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width={badgeIconSize}
                height={badgeIconSize}
                fill="currentColor"
                className="bi bi-chat-right-dots-fill"
                viewBox="0 0 16 16"
              >
                <path d="M16 2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h9.586a1 1 0 0 1 .707.293l2.853 2.853a.5.5 0 0 0 .854-.353zM5 6a1 1 0 1 1-2 0 1 1 0 0 1 2 0m4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m3 1a1 1 0 1 1 0-2 1 1 0 0 1 0 2" />
              </svg>
            </MiniBadge>
            <MiniBadge count={Update} badgeColor={'bg-zinc-800 text-zinc-200'} padding={"mr-2"}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width={badgeIconSize}
                height={badgeIconSize}
                fill="currentColor"
                className="bi bi-clipboard-check"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0"
                />
                <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1z" />
                <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0z" />
              </svg>
            </MiniBadge>
            <MiniBadge count={Issues} badgeColor={'bg-zinc-800 text-zinc-200'} padding={"mr-2"}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width={badgeIconSize}
                height={badgeIconSize}
                fill="currentColor"
                className="bi bi-exclamation-circle-fill"
                viewBox="0 0 16 16"
              >
                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M8 4a.905.905 0 0 0-.9.995l.35 3.507a.552.552 0 0 0 1.1 0l.35-3.507A.905.905 0 0 0 8 4m.002 6a1 1 0 1 0 0 2 1 1 0 0 0 0-2" />
              </svg>
            </MiniBadge>
          </div>
          <div className="h-5/6 w-full">
            <div className="">
              <p className='text-xl'>
                {GroupName}
            </p>
            </div>

            <div className="">
              <p className=" text-xs ">{messages}</p>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};
export default Events;
