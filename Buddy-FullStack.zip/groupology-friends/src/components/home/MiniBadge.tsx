import React from 'react'
interface data{

}// these are mini badges max fit in the section are 6 , they are used by the tailwind calass of widths w-1/6 of total 
const MiniBadge = ({children, count,badgeColor,textColor,padding}:any) => {
    const Count = count;
  return (
    <div className={` w-9 h-auto  ${badgeColor} ${textColor} ${padding} rounded-full flex flex-row items-center justify-evenly `}>
        {children}
        <p className='text-xs '>
            {Count}
        </p>
    </div>
  )
}

export default MiniBadge