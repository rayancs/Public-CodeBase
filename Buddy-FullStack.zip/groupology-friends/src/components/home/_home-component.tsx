'use client'
import Image from 'next/image'
import React, { useEffect, useState } from 'react'
import Person from '@/assets/person.png'
import Groups from '@/assets/groups.png'
import People from '@/assets/findPeople.png'
import PlanSomething from '@/assets/planSomething.png'
import Announcements from '@/assets/announcement.png'
import { BsPlay } from 'react-icons/bs'
import { BiSolidNotification } from 'react-icons/bi'
import Events from './Events'
import Link from 'next/link'
type model = {
  email:string
  friends:[]
  id:string
  firstname:string
  name:string
  picture:string
}
export const Homecomponent = () => {
  const [user , set_user] = useState<model |null>(null)
    const GetUserData = async ()=>{
      
        try{
            const _res = await fetch('/api/users',{
                method:"GET",
                headers:{
                    "Content-Type":"application/json"
                }
            }).then((res)=>res.json()).then((data)=>{
                // data.res will reveal the data array from the result object 
                const user = data.res
                set_user(user)
            })            
        }catch (error){
            console.log(error)
        };
    }
    useEffect(()=>{
      if(user === null){
        GetUserData()
      }
    },[])
  return (
    <>
    <div className=' w-full h-auto'>
      <section id='top-info-bar'>
      <div className='h-auto sm:h-56 w-[70%] mx-auto max-w-[1024px] ' id='top-bar'>
          <div className='h-full'>
            <section>
              <div className=' flex flex-row w-full justify-between'>
                <span>
                  {
                      user?.picture ? 
                      <img src={user.picture}  className=' mt-4 rounded-full h-10 w-10'></img>
                      :
                      <span className=''>
                        <Image src={Person} alt='' height={70} width={70} className='pt-2 rounded-full h-30 w-30'/>
                      </span>
                    }
                </span>
                <span className=' w-9 h-6 sm:h-10 sm:w-12 bg-zinc-200  rounded-full mt-4 flex items-center justify-evenly hover:bg-green-200 transition-all ease-in-out duration-200'>
                    <BiSolidNotification className='w-8 h-5 sm:h-9 sm:w-9'/>
                </span>
              </div>
            </section>
            <span >
              {user?.name ? 
                <p className=' text-zinc-100 font-bold text-6xl sm:text-4xl pt-4'>
                {user.firstname}  
                </p>
                :<p>
                  not logged in
                </p>
                }
            </span>
            <section>
              <span>
                {
                  user?.email ? 
                <p className=' text-zinc-300  mt-2 ml-2'>
                  {user?.email}
                </p>
                :
                  <span className=''>
                  </span>
                }
              </span>
            </section>
          </div>
        </div>
      </section>
      <section id='carosel'>
        <ul className=' max-w-[1024px]  justify-evenly h-auto pb-4 overflow-x-scroll flex flex-row flex-shrink-0 gap-4 sm:gap-2 sm:grid sm:grid-flow-row sm:grid-cols-2  sm:overflow-hidden mt-10 sm:mt-0 w-[98%] mx-auto '>
          <Link href={'/findpeople'} className='  sm:bg-zinc-950 border border-zinc-700 text-zinc-200  flex-shrink-0 rounded-md  sm:rounded-md h-80 sm:h-60 w-[65%] sm:w-auto shadow-sm hover:scale-95 active:scale-95 transition-all ease-in-out duration-200 flex justify-between items-center flex-col sm:active:scale-100' > 
                  <p className=' pl-2 pr-2 font-bold text-2xl sm:text-3xl pt-4 pb-1'>Find More People</p>
                  <p className='text-center text-xs text-zinc-400 w-3/4'>Create A New Group Add Plans ,Have Fun With Your Friends</p>
                  <Image src={People} height={150} width={150} alt='..' className='pb-3'/> 
          </Link>
          <Link href={'/groups'}  className='  sm:bg-zinc-950 border border-zinc-700 text-zinc-200 flex-shrink-0 rounded-md sm:rounded-md h-80 sm:h-60 w-[65%] sm:w-auto shadow-sm hover:scale-95 active:scale-95 transition-all ease-in-out duration-200 flex justify-between items-center flex-col sm:active:scale-100' >
                <p className=' font-bold text-2xl sm:text-3xl pt-4 pb-1'>Manage Groups</p>
                <p className='text-center text-xs text-zinc-400 w-3/4'>Create A New Group Add Plans ,Have Fun With Your Friends</p>
                <Image src={Groups} height={150} width={150} alt='..' className=''/>
          </Link>
          <Link href={'/plans'}  className='  sm:bg-zinc-950 border border-zinc-700 text-zinc-200  flex-shrink-0 rounded-md h-80  sm:rounded-md sm:h-60 w-[65%] sm:w-auto shadow-sm hover:scale-95 active:scale-95 transition-all ease-in-out duration-200 flex justify-between items-center flex-col sm:active:scale-100 ' >
                <p className=' font-bold text-2xl sm:text-3xl pt-4 pb-1'>Make Plans</p>
                <p className='text-center text-zinc-400 text-xs w-3/4'>Making Plans With Friends Has Never Been Easier than this</p>
                <Image src={PlanSomething} height={150} width={150} alt='..' className='bg-4'/>
          </Link>
          <Link href={'/notify'}  className='  sm:bg-zinc-950 border border-zinc-700 text-zinc-200  flex-shrink-0 rounded-md h-80  sm:rounded-md sm:h-60 w-[65%] sm:w-auto shadow-sm hover:scale-95 active:scale-95 transition-all ease-in-out duration-200 flex justify-between items-center flex-col sm:active:scale-100' >
                <p className='text-zinc-200 font-bold text-2xl sm:text-3xl pt-4 pb-1'>Announcements</p>
                <p className='text-center text-zinc-400 text-xs w-3/4'>All of Your Notifications in One Place, the Announcements Board</p>
                <Image src={Announcements} height={140} width={140} alt='..' className='bg-4'/>
            </Link>
        </ul>
      </section>
      <section id='Activity'>
       <div className=' mx-auto w-[98%] max-w-[1024px] pb-20 ' id='container'>
                <span className='' id='text-headin'>
                  <p className=' text-zinc-200 text-3xl mt-4 pl-2 pb-2'>
                    Activity
                  </p>
                </span>
                <section>
                  <div className='grid grid-col-2 grid-flow-row gap-2'>
                    <Events
                      GroupName='Final Project'
                      messageCount='3'
                      messages={['Please Update All of the records']}
                      Update='0'
                      Issues='2'
                      />
                      <Events
                      GroupName='Uni Projects'
                      messageCount='0'
                      messages={['any update for the results']}
                      Update='0'
                      Issues='20'
                      />
           
           
                  </div>
                </section>
       </div>
      </section>
    </div>
    </>
  )
}
export default Homecomponent
