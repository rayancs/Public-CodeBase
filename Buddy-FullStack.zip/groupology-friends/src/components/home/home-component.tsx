'use client'
/*
import React, { useState } from 'react'
import Groups from '@/assets/groups.png'
import People from '@/assets/findPeople.png'
import Person from '@/assets/person.png'
import PlanSomething from '@/assets/planSomething.png'
import { useUser } from '@auth0/nextjs-auth0/client'
import Announcements from '@/assets/announcement.png'
import Image from 'next/image'
import Announcements from '@/assets/announcement.png'
import { MdEmail } from 'react-icons/md'

const homecomponent = () => {
    const { user, error, isLoading } = useUser();
    const [userInfo , setUserInfo] = useState<string>("");
  return (
    <>
        <div className='flex flex-col h-auto   sm:grid-cols-3 sm:grid sm:grid-row-auto sm:grid-col-1 gap-2 sm:w-5/6 pt-4 pb-4 mx-auto w-full sm:h-5/6'>
            <div className='bg-zinc-800 col-span-2 h-80 rounded-lg shadow-sm  hover:scale-95 active:scale-95 transition-all ease-in-out duration-200'>
                <div className='h-3/6 w-full bg-zinc-800 flex justify-evenly items-center  rounded-t-lg border-b border-zinc-700 shadow-sm '>
                   <div className='h-auto'>
                    {user?.picture ? 
                    (<img className='h-5/6 p-4 aspect-square rounded-full' src={user?.picture|| ""} ></img>) 
                    :(<div className='w-25 relative aspect-square m-4 rounded-full bg-orange-900'><Image alt='...' src={Person} height={100} width={100} className='rounded-full h-full'></Image></div>)}
                   </div>
                   <div className='w-4/6 h-full flex justify-start md:justify-evenly items-center'>
                    {user?.name ? (<p className=' text-zinc-300 text-2xl text-center w-full'>{user.name}</p>):(<p className=' text-zinc-300 w-5/6 sm:w-full text-center text-2xl '>not signed in ?</p>)}
                   </div>
                </div>
                <div className=' w-4/6 h-6 flex justify-around items-center mx-auto pt-4'>
                    <MdEmail className='text-zinc-300 sm:visible sm:h-5 sm:w-5'/>
                    <p className='text-zinc-200 text-center pl-4'>{user?.email}</p>
                </div>
            </div>
            <div className='bg-blue-400 rounded-lg h-80 shadow-sm hover:scale-95 active:scale-95 transition-all ease-in-out duration-200 flex justify-between items-center flex-col  ' > 
                <p className='text-zinc-200 font-bold text-3xl pt-4'>Find More People</p>
                <p className='text-center text-xs w-3/4'>Create A New Group Add Plans ,Have Fun With Your Friends</p>
                <Image src={People} height={200} width={200} alt='..' className='pb-3'/>
            </div>
            <div className='bg-orange-400 h-80 rounded-lg shadow-sm hover:scale-95 active:scale-95 transition-all ease-in-out duration-200  flex justify-between items-center flex-col' >
                <p className='text-zinc-200 font-bold text-3xl pt-4'>Manage Groups</p>
                <p className='text-center text-xs w-3/4'>Create A New Group Add Plans ,Have Fun With Your Friends</p>
                <Image src={Groups} height={200} width={200} alt='..' className=''/>
            </div>
            <div className='bg-purple-400 h-80  rounded-lg shadow-sm hover:scale-95 active:scale-95 transition-all ease-in-out duration-200  flex justify-between items-center flex-col' >
                <p className='text-zinc-200 font-bold text-3xl pt-4'>Make Plans</p>
                <p className='text-center text-xs w-3/4'>Making Plans With Friends Has Never Been Easier than this</p>
                <Image src={PlanSomething} height={200} width={200} alt='..' className='bg-4'/>
            </div>
            <div className='bg-pink-500 h-80 rounded-lg shadow-sm hover:scale-95 active:scale-95 transition-all ease-in-out duration-200 flex justify-between items-center flex-col' >
                <p className='text-zinc-200 font-bold text-3xl pt-4'>Announcements</p>
                <p className='text-center text-xs w-3/4'>All of Your Notifications in One Place, the Announcements Board</p>
                <Image src={Announcements} height={200} width={200} alt='..' className='bg-4'/>
            </div>
        </div>
          {/*<style jsx>
              {
                  `
            .custom-width{
                max-width:1024px;
            }
            @media screen and (max-width: 768px) {
                .element {
                  width: 95%; /* Set width to 95% for phone screens 
                }
            }
            `
              }
          </style> /}
          
    </>
  )
}

export default homecomponent*/