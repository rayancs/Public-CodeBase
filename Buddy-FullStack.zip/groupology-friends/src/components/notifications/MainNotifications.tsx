'use client'
import { request } from 'http'
import React, { use, useEffect, useState } from 'react'
import { BsCheck, BsX } from 'react-icons/bs'

type user = {
  email:string
  firstname:string
  isAccepted:boolean
  picture:string
  
}
export const MainNotifications = () => {
  const [requests , set_requests] = useState<user[]>([]);
  const [show_options , set_show_options] = useState<boolean[]>([])



  const show_more_options=(index:number )=>{
    const updated_opt = [...show_options]
    updated_opt[index]= !show_options[index]
    set_show_options(updated_opt)
  }
  function remove_user_from_list( index:number){
    const updatedArray =[...requests]
    const filter = updatedArray.filter((_,_index)=>_index !== index)
    set_requests(filter)

  }
  async function accept_request(email:string){
    try{
      const res = await fetch('api/friends/accept',{
        method:'POST',
        headers:{
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user:{email}})
      });
      if(!res.ok){
        throw new Error('Failed to submit form data');
      }
      console.log('Form data submitted successfully'+res);
    }
    catch(ex){
      console.log(ex)
    }
  }
  async function reject_request(email:string){
    try{
      const res = await fetch('api/friends/reject',{
        method:'POST',
        headers:{
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user:{email}})
      });
      if(!res.ok){
        throw new Error('Failed to submit form data');
      }
      console.log('Form data submitted successfully'+res);
    }
    catch(ex){
      console.log(ex)
    }
  }
    const GetFriendsData = async ()=>{
      try{
          const _res = await fetch('/api/friends',{
              method:"GET",
              headers:{
                  "Content-Type":"application/json"
              }
          }).then((res)=>res.json()).then((data)=>{
              // data.res will reveal the data array from the result object
              // this is working 
              set_requests(data.res.friend)

          })            
      }catch (error){
          console.log(error)
      };
  }


  useEffect(()=>{
    GetFriendsData()
  },[])

  return (
    <>
        <div className=' w-5/6 mx-auto max-w-[1280px] h-auto'>
            <section id='top-bar'>
              <p className='text-zinc-200 font-bold text-3xl pr-2 mt-8'>
                Notifications
              </p>
              <p className=' text-zinc-500 font-thin pr-3 mt-2'>
                All of Your Notifcations and Friend Requests are Here
              </p>
            </section>
            <section id=''>
                <div className='w-full sm:grid sm:grid-cols-2 flex flex-col sm:grid-flow-col '>
                      {requests?.filter(x=>!x.isAccepted).map((x , identifier) =>(
                        <div key={identifier} onClick={()=>show_more_options(identifier)} className={`relative  overflow-hidden w-[95%] sm:w-[100] flex flex-row h-20 border-t border bg-zinc-800 rounded-xl border-zinc-800 mx-auto mt-5`}>
                          <div className='w-2/6'>
                            <span>
                              <img src={x.picture} className=' ml-2 mt-2 shadow-sm h-auto  w-9 rounded-full '/>
                            </span>
                          </div>
                          <div>
                            <p className=' text-zinc-400 pt-2 h-9 w-full overflow-hidden'>
                              {x.firstname}
                            </p>
                            <p className='text-zinc-600 text-xs'>
                            {x.email}
                            </p>
                          </div>
                        
                          <div id='overlay' className={` ${show_options[identifier] ? ' bottom-0': ' -bottom-32'}  left-0 w-full h-full absolute glass  transition-all ease-in-out duration-200 `}>
                            <div className=' flex flex-row justify-evenly items-center h-full'>
                              <button className=' w-10 h-10 bg-green-600 bg-opacity-30 border-green-500 border rounded-full '>
                                <BsCheck className='h-9 w-9 text-green-200' onClick={()=>{
                                  remove_user_from_list(identifier);
                                  accept_request(x.email);
                                  }
                                }></BsCheck>
                              </button>
                              <button className=' w-10 h-10 bg-red-600 bg-opacity-30 border-red-500 border rounded-full '>
                                <BsX onClick={()=>{
                                  remove_user_from_list(identifier)
                                  reject_request(x.email)
                                  }} className='h-9 w-9 text-red-200'></BsX>
                              </button>
                            </div>

                          </div>
                      </div>
                      ))
                      }
                </div>
            </section>
        </div>
        <style jsx>{`
        .glass{
        backdrop-filter: blur(5px);
        -webkit-backdrop-filter: blur(5px);
        }
        `}</style>
    </>
  )
}
