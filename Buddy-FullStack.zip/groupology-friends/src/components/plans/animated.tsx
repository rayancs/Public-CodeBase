import React, { useEffect, useState } from 'react';
import { motion, useMotionValue, useMotionValueEvent, useTransform } from "framer-motion"
import { group } from 'console';
import { Tulpen_One } from 'next/font/google';
type task={
    id:string
    for_email:string,
    title:string,
    Description:string,
    endDate?:string,
    groupId?:string  
  
}

const TaskComponent: React.FC =()=> {
  const [group_data , set_group_data] = useState<task[]>([]);
  const [done,set_done] = useState<boolean>(false)
  const [reject,set_reject] = useState<boolean>(false)
  
  const fetch_group_info = async()=>{
    try{
     await fetch('/api/tasks',{
        method:"GET",
        headers:{
            "Content-Type":"application/json"
        }
    }).then((res)=>res.json()).then((data)=>{
        // data.res will reveal the data array from the result object
        // this is working
        set_group_data(data.res);
    })     
    }catch(ex){
    }
  }
  useEffect(()=>{
  for ( let i =0; i<group_data.length; i++ ){
    console.log(group_data[i])
  }
  },[group_data]
)
  useEffect(()=>{
    fetch_group_info()
  },[])
  /* for the swiping animation */
  const x = useMotionValue(1)
  useMotionValueEvent(x, "animationStart", () => {
    console.log("animation started on x")
  })
  useMotionValueEvent(x, "change", (latest) => {
    DoneOrReject(latest)
  });
  function DoneOrReject(val:number){
    console.log(val)
    if (val > 200 ){
      console.log(done +" accepted")
      set_reject(false)
      set_done(true)

    }
    if (val < -200){
      set_done(false)
      doReject()
      set_reject(true)
    }
  }
  function doReject(){
  
  }
  function doDone(){

  }
  return (
    <>
    {group_data.map((i,idnf)=>
      (<>
        <motion.div
        key={idnf}
        style={{x}}
          className='h-44 mx-auto flex flex-row bg-zinc-950 border border-zinc-700 mt-2 rounded-lg'
        drag ='x'
        dragConstraints={{
          left: 0,
          right: 0,
        }}
        >
          <div className={` w-16 sm:w-24 h-full bg-zinc-900 border-r border-zinc-700 rounded-l-md flex flex-col items-center justify-evenly`} id='time-left-section'>
            <p className=' text-zinc-800 rotate-90 w-full text-center'>
            {i.endDate}
            </p>
          </div>
          <div className=' '>
            <p className=' text-2xl sm:text-3xl  text-zinc-100 ml-3 overflow-hidden h-12 mt-3 '>
              {i.title}
            </p>
            <p className=' h-5 mt-2 text-xs text-zinc-200   ml-4 pl-1 pr-1 rounded-full  flex flex-col items-center justify-evenly  bg-[#588157] w-fit'>
              from "{}"
            </p>
            <p className=' h-14 text-zinc-400  ml-2 '>
              {i.Description}
            </p>
          </div>
        </motion.div>
      </>
      )
      
    )
    
    }
    </>
   

  );
};

export default TaskComponent

