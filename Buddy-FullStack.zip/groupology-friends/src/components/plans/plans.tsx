'use client'
import React, { useEffect, useState } from 'react'
import Link from 'next/link';
import { GrAdd, GrAddCircle } from 'react-icons/gr';
import  TaskComponent  from './animated';
export const EventComponent = () => {
  return (
    <>
    <div className=' w-[97%] relative  max-w-[1280px] mx-auto'>
      <section id=' top-bar'>
        <div className=' flex flex-row justify-between'>
          <div className=' h-12 bg-zinc-200 ml-4 mt-4 w-32 rounded-sm'>
            <div className=' h-12 w-32 -translate-x-1 -translate-y-1 flex items-center justify-evenly text-3xl font-bold rounded-sm text-zinc-100  bg-[#a3b18a]'>
              PLANS
            </div>

          </div>
         
          <div className='   w-14 rounded-full  text-3xl text-zinc-200  flex items-center justify-evenly h-14 fixed bottom-2 bg-[#a3b18a] left-[80%]  -translate-y-[4rem]  mt-6'>
                <GrAdd className=' text-zinc-10 flex items-center justify-normalfont-bold'/>
          </div>
        </div>
      </section>
      <section>
        
        <TaskComponent/>
      </section>
    </div>
    </>

  )
}
