import React, { useState } from 'react';

const TaskComponent: React.FC = () => {
  const [position, setPosition] = useState<number>(0);
  const [startX, setStartX] = useState<number | null>(null);

  const handleStart = (clientX: number) => {
    setStartX(clientX);
  };

  const handleMove = (clientX: number) => {
    if (startX !== null) {
      const difference = clientX - startX;
      setPosition(difference);
    }
  };

  const handleEnd = () => {
    if (startX !== null && position < -100) {
      console.log('Swiped left');
    } else if (startX !== null && position > 100) {
      console.log('Swiped right');
    }
    setPosition(0);
    setStartX(null);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    handleStart(e.touches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    handleMove(e.touches[0].clientX);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    handleStart(e.clientX);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    handleMove(e.clientX);
  };

  return (
    <div
      className="w-64 h-64 bg-gray-300 relative"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleEnd}
    >
      <div
        className="h-full w-full bg-blue-500 absolute top-0 left-0"
        style={{ transform: `translateX(${position}px)` }}
      ></div>
    </div>
  );
};

export default TaskComponent

