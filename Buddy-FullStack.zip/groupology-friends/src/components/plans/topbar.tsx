import React from 'react'

const Topbar = () => {
  return (
    <>
     <div className='w-95 border-custom h-20'>
            <div className=' flex flex-row h-full justify-between' id='Page-Inforamtion'>
                <div className='w-2/6 h-full flex flex-col items-center justify-evenly'>
                    <p className={`text-zinc-200 text-3xl w-full font-bold`}>
                        {'Plans'}
                    </p>
                    <p className={`text-zinc-200 text-xs font-thin w-full flex items-start pl-1  `}>
                        {'All of Your Plans Are Here'}
                    </p>
                </div>
                <div className='w-4/6 flex items-center justify-evenly'>
                    <input className='w-5/6 h-10 max-w-[420px] outline-none transition-all rounded-3xl  duration-300 ease-in-out text-center text-zinc-200 bg-zinc-700 text-xs '
                        type='text'
                        placeholder='SEARCH'
                        >
                    </input>
                </div>
            </div>
    </div>
    <style jsx>
        {
            `
            .w-95{
                width:95%;
            }
            .border-custom{
                border-bottom:1px solid grey;
            }
            `
        }
    </style>
    </>
   
  )
}

export default Topbar