'use client'
import Link from 'next/link'
import React from 'react'
import { BsChatSquare, BsChatSquareDots, BsChatSquareDotsFill, BsCupHot, BsCupHotFill, BsPeopleFill, BsPersonFill, BsPersonFillAdd } from 'react-icons/bs'
import JSXStyle from 'styled-jsx/style'

const Navbar = () => {
  return (
    <>
    <div className=' max-w-96 w-5/6 h-12  rounded-full  fixed transition-all ease-in-out duration-200 text-zinc-200 bg-zinc-900 bottom-2 left-1/2 transform -translate-x-1/2 flex justify-evenly items-center '>
        <Link href={'/'} className=' w-2/6 h-full flex justify-evenly items-center  border-zinc-400 border-opacity-60'>
            <BsCupHotFill className=' min:h-7 h-full w-full p-2 hover:text-lime-400  hover:scale-110 hover:translate-y-[-10px] duration-200 ease-in-out transition-all'/>
        </Link>
        <Link href={'/accounts'} className='w-2/6 h-full  flex justify-evenly items-center border-zinc-400 border-opacity-60'>
            <BsPersonFill className=' min:h-7 h-full w-full p-2 hover:text-lime-400  hover:scale-125 hover:translate-y-[-10px] duration-200 ease-in-out transition-all'/>
        </Link>
        <Link href={'/findpeople'}  className='w-2/6 h-full  flex justify-evenly items-center border-zinc-400 border-opacity-60'>
            <BsPersonFillAdd className='min:h-7 h-full w-full p-2 hover:text-lime-400 hover:scale-110 hover:translate-y-[-10px] duration-200 ease-in-out transition-all'/>
        </Link>
        <Link href={'notifications'} className='w-2/6 h-full  flex justify-evenly items-center'>
            <BsChatSquareDotsFill className='min:h-7 h-full w-full p-2 hover:text-lime-400 hover:scale-110 hover:translate-y-[-10px] duration-200 ease-in-out transition-all'/>
        </Link>
    </div>
    <style jsx>{
        ` glass:{
           /* From https://css.glass */
                background: rgba(255, 255, 255, 0.01);
                                
                box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
                backdrop-filter: blur(12.4px);
                -webkit-backdrop-filter: blur(12.4px);
                border: 1px solid rgba(255, 255, 255, 0.3);
           }`
        }
    </style>
    </>
  )
}

export default Navbar