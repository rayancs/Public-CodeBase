import React, { useEffect, useState } from 'react';
interface data{
  str?:string
}
const Notifications: React.FC<data> = ({str}) => {
  const [RedSize, setRedSize] = useState<boolean>(false);
  const doSum =()=>{
    console.log('do sum1')
    if (str == '' || str== null || str == undefined){
     return
    }
    if (str !== '' || str!== null) {
      setRedSize(true); // If str is not empty, set RedSize to true
      const timeout = setTimeout(() => {
        setRedSize(false); // Set RedSize to false after 300 seconds (300000 milliseconds)
      }, 3000);
      return () => clearTimeout(timeout); // Clear the timeout when the component unmounts or when RedSize changes
    }
  }
  useEffect(() => {
   doSum()
  }, [str]);

  return (
    <>
     <div className={`max-w-[1024px] fixed overflow-hidden flex items-center justify-evenly top-2 left-1/2 transform -translate-x-1/2 ${RedSize ? 'rounded-3xl sm:w-96 h-20' : 'w-0 h-0'} bg-zinc-100 mx-auto duration-300 ease-in-out transition-all`} id='top-nav'>
      <p className='text-zinc-800 font-medium sm:font-2xl text-bold h-auto w-[95%] text-center'>{str}</p>
     </div>
    </>
   
  );
};

export default Notifications;






















/*import React, { useEffect, useState } from 'react'
const notifications = (str:string) => {
const [RedSize ,setRedSize] = useState<boolean>(false)
  const reduceSize=()=>{
    setRedSize(!RedSize)
  }
  useEffect(()=>{
    reduceSize();
  },[RedSize])
  return (
    <>
    <div className={ `max-w-[1024px] fixed top-2 left-1/2 transform -translate-x-1/2   ${RedSize ? ' rounded-3xl  sm:w-96 h-20 ' : '  w-0 h-0'} bg-zinc-800  mx-auto  duration-300 ease-in-out transition-all'`} id='top-nav'>
                  <div className=''>
                    <p>
                      {str}
                    </p>
                  </div>
    </div>
    </>
  )
}

export default notifications*/