"use client"
import React, { useEffect, useState } from 'react'
import Person from '@/assets/person.png'
import { useUser } from '@auth0/nextjs-auth0/client'
import Image from 'next/image'
import { Button } from '../ui/button'
import { Mail } from 'lucide-react'
import { TUserModel } from '@/models/groups_model'
type model = {
    email:string
    friends:[]
    id:string
    name:string
    picture:string
}
const UserDasboard =() => {
    function trimString(input: string): string {
        const trimmedString = input.trim();
        if (trimmedString.length > 20) {
          return trimmedString.slice(0, 20) + '..';
        }
        return trimmedString;
      }
    const [user , set_user] = useState<model |null>(null)
    const GetUserData = async ()=>{
        try{
            const _res = await fetch('/api/users',{
                method:"GET",
                headers:{
                    "Content-Type":"application/json"
                }
            }).then((res)=>res.json()).then((data)=>{
                // data.res will reveal the data array from the result object 
                const user = data.res
                set_user(user)
            })            
        }catch (error){
            console.log(error)
        };
}
    useEffect(()=>{
        GetUserData()
    },[])
  return (
    <div className=' text-zinc-100 h-screen w-screen flex justify-center items-center'>
        <div className=' w-5/6 h-3/6 lg:w-4/6 border-zinc-800 border rounded-lg'>
            <div className='h-2/6 flex justify-around items-center flex-row' id='top-container'>
                <div className='w-2/6 h-full'>
                    {user?.picture? 
                    (<img className='h-5/6 p-4 aspect-square rounded-full' src={user.picture} ></img>) 
                    :(<div className='h-5/6 relative aspect-square m-4 rounded-full bg-orange-900'><Image alt='...' src={Person} height={500} width={500} className='rounded-full h-full'></Image></div>)}
                </div>
                    <div className='w-4/6 h-full flex justify-evenly items-center'>
                    {user?.name ? (<p className=' text-zinc-300 text-2xl w-4/6'>{trimString(user?.name)}</p>):(<p className=' text-zinc-300 w-5/6 sm:w-full text-center text-2xl '>not signed in ?</p>)}
                </div>
            </div>
            <div className='w-5/6 border border-zinc-900 m-auto ' id='divider'/>
            <div className='w-full flex justify-evenly items-center h-2/6'>
                {user?.email ? (<p className='text-base sm:text-2xl'>{user?.email}</p>):(<p className='text-xl sm:text-2xl '>email</p>)}
            </div>
            <div className='w-full flex justify-evenly items-center h-2/6'>
                {user ? 
                (<>
                    <a href='api/auth/logout' className='w-40 h-11 items-center justify-evenly rounded-sm flex felx-row bg-zinc-100 text-sm text-zinc-900 transition-all ease-in-out duration-300 active:scale-110 hover:bg-zinc-300'>
                    <Mail className='text-zinc-800'/>Logout
                </a>
                </>):
                (<>
                <a href='api/auth/login' className='w-40 h-11 items-center justify-evenly rounded-sm flex felx-row bg-zinc-100 text-sm text-zinc-900 transition-all ease-in-out duration-300 active:scale-110 hover:bg-zinc-300'>
                    <Mail className='text-zinc-800'/>Login/SignUp
                </a>
                </>)}
            </div>
            

        </div>
    </div>
  )
}

export default UserDasboard