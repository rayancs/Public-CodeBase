export type TUserModel={
    email:string
    friends:[]
    id:string
    name:string
}
export type group_model={
    name:string
    admin_email:string,
    people :string[],
    tasks:[{
        for_email:string,
        title :string,
        Description :string,
        end_date ?:Date 
    }]
}