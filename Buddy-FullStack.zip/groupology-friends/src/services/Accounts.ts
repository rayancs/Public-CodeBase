import { db } from "@/lib/db";
import { getSession } from "@auth0/nextjs-auth0";

export  async function loginUser(){
    const user = await getSession();
    if(!user) return null
    const { email,given_name,   name, picture } = user.user;
    const accessToken = user.accessToken
        try{
        if (!email||!name||!accessToken) return null
        const old_uer=await db.user.findFirst({where:{email:email}})
        if (!old_uer){
            const new_user = await db.user.create({
                data:{
                    email:email,name:name,picture:picture,firstname:given_name
                }
            })
            return new_user
        }
        const find_friends_table = await db.friends.findFirst({where:{useremail:email}})
        if (!find_friends_table){
            await db.friends.create({
                data:{
                    useremail:email,
                    friend:[]
                }
            })
        }
        return old_uer
        }catch(error) {
        console.error("Error:", error);
        }
        finally{
            db.$disconnect();
        }
}

export async function getFriendsData(){
    const user = await getSession();
    if(!user) return null
    const { email} = user.user;
    const accessToken = user.accessToken
    try{
        if (!email||!accessToken) return null
        const old_uer=await db.friends.findFirst({where:{useremail:email}})
        if(!old_uer) return null
        return old_uer

    }catch(error){
       throw  error;
    }
}
export async function addFriend(finduser:string){
    const user = await getSession();
    if(!user) return "not_logged_in"
    const accessToken = user.accessToken
    const { email} = user.user;
    try{
        // add  the current user to requeste if accepted add it to current users email , that is done seperatly 
        if (!email||!accessToken) return null
        const userExists = await db.friends.findUnique({
            where: {
                useremail: finduser
            }
        });
        if (!userExists){
            return null
        }
        if (userExists.useremail === email){
            return null
        }
        if (userExists && userExists.friend.some(f => f.email === email)) {
            return "req_already_sent";
        }
        const getDetaildFriend = await db.user.findFirst({where:{email:email}})
        console.log(getDetaildFriend?.email+""+getDetaildFriend?.firstname)
        if (!getDetaildFriend) return null
        const addFriendRes = await db.friends.update({
            where:{
                useremail:finduser
            },
            data:{
               friend:{
                push:{ 
                firstname:getDetaildFriend.name,
                picture:getDetaildFriend.picture,
                email:email, 
                isAccepted:false
                }
               }
            }
        })
        if (addFriendRes){
            return "req_sent"
        }
        return null
    }
    catch (error){
        throw error
    }
}
export async function  acceptFriendRequest(req:string) {
    const user = await getSession();
    if(!user) return null
    const accessToken = user.accessToken
    if (!accessToken) return null
    const { email} = user.user;
    try{
        const userExists = await db.friends.findUnique({
            where: {
                useremail: email
            }
        });
        if (!userExists){
            return null
        }
        if (userExists.useremail !==email){
            return null
        }
        if (!userExists.friend.some(f => f.email === req)){
         return null}
        var res =  await db.friends.update({
            where: {
                useremail: email,
            },data:{
                friend:{
                    updateMany:{
                        where:{
                            email:req
                        },
                        data:{
                            isAccepted:true
                        }
                    }
                }
            }
        })
        if (!res){
        console.log(res+"res");
        }
        return 'success'
    }catch(error){
        throw error
    }
}
export async function remove_friend(req:string){
    const user = await getSession();
    if(!user) return null
    const accessToken = user.accessToken
    if (!accessToken) return null
    const { email} = user.user;
    try{
        const userExists = await db.friends.findUnique({
            where: {
                useremail: email
            }
        });
        if (!userExists){
            return null
        }
        if (userExists.useremail !==email){
            return null
        }
        if (!userExists.friend.some(f => f.email === req)){
         return null}
        var res =  await db.friends.update({
            where: {
                useremail: email,
            },data:{
                friend:{
                     deleteMany:{
                        where:{
                            email:req
                        },
                    }
                }
            }
        })
        if (!res){
        console.log(res+"res");
        }
        return 'success'
    }catch(error){
        throw error
    }
}

    


