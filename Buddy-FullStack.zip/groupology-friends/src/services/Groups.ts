import { db } from "@/lib/db";
import { getSession } from "@auth0/nextjs-auth0";
import { group_model } from "@/models/groups_model";
import { equal } from "assert";
export async function create_groups(group:group_model) {
    const user = await getSession();
    const accessToken = user?.accessToken
    if (!accessToken) return null
    const {email} = user?.user
    // find if the user exsits in the user db 
    try{
        // find the user 
        const user = await db.user.findFirst({
            where:{
                email:email
            }
        })
        if (!user) return 404
        /* old method where task was a embeded type keep safe for future refrence 
        const createdGroup = await db.groups.create({
            data: {
                name:group.name,
                admin_email:email,
                people: group.people,
                tasks: group.tasks.map((task) => ({
                    for_email: task.for_email,
                    title: task.title,
                    Description: task.Description,
                    endDate: task.end_date,
                  })),
            }
        });*/
        const createdGroup = await db.groups.create({
            data: {
              name: group.name,
              admin_email: email,
              people: group.people,
              tasks: {
                create: group.tasks.map((task) => ({
                  for_email: task.for_email,
                  title: task.title,
                  Description: task.Description,
                  endDate: task.end_date, // Make sure to use endDate instead of end_date
                })),
              },
            },
          });
        if (!createdGroup) return 204
        return createdGroup
    }catch(ex){
        throw ex
    }
}
// get all service
export async function get_all_groups() {
    const user = await getSession();
    const accessToken = user?.accessToken
    if (!accessToken) return ''
    const {email} = user?.user
    try{
        const res = await db.groups.findMany({
            where: {
                OR: [
                    { admin_email: email },
                    { people: { has: email } }
                ]
            }
        });
        if (!res)return null
        return res;
    }catch(ex){
        throw ex
    }
}
export async function get_tasks(){
    const user = await getSession();
    const accessToken = user?.accessToken
    if (!accessToken) return ''
    const {email} = user?.user
    try{
        const res = await db.task.findMany({
            where: {
                for_email:email                
            }
        });
        if (!res)return null
        return res;
    }catch(ex){
        throw ex
    }
}