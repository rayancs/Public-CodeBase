'use server'
 
import { redirect } from 'next/navigation'
 
export async function navigate_to_home(){
  redirect(`/`)
}