export default function log (str:string){
     return {res:{str}}
}